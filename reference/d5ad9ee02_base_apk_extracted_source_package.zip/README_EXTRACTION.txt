APK extraction package
=======================

Input: base(1).apk
SHA-256: 4dbacf6bfc2d6b096bedfe95b246483028ed421297d8d88985cfc8d43ade4a39
APK size: 6,205,626 bytes
Archive entries: 365

Contents:
- AndroidManifest.xml: binary Android manifest
- classes.dex: compiled Dalvik/ART bytecode (not original Java/Kotlin source)
- assets/: application assets, including fonts, UI graphics, themes and sounds
- res/: Android resources
- lib/: native libraries for multiple CPU ABIs
- META-INF/: signing/packaging metadata

Important:
This package contains the files that can be directly extracted from the APK.
It does NOT recreate the developer's original Gradle/Android Studio project or
guarantee recovery of the original source code. To study program logic, classes.dex
must be decompiled/disassembled with an appropriate DEX decompiler.
